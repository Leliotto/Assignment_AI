#  (C) Copyright Wieger Wesselink 2021. Distributed under the GPL-3.0-or-later
#  Software License, (See accompanying file LICENSE or copy at
#  https://www.gnu.org/licenses/gpl-3.0.txt)

import random
import time
from competitive_sudoku.sudoku import GameState, Move, SudokuBoard, TabooMove
import competitive_sudoku.sudokuai

from typing import List, Optional, Tuple

Square = Tuple[int, int]

class SearchState:
    def __init__(
        self,
        board: SudokuBoard,
        scores: List[int],
        current_player: int,
        allowed_squares1: Optional[List[Square]],
        allowed_squares2: Optional[List[Square]],
        occupied_squares1: Optional[List[Square]],
        occupied_squares2: Optional[List[Square]],
        taboo: set[Tuple[int, int, int]],
    ):
        self.board = board
        self.scores = scores
        self.current_player = current_player
        self.allowed_squares1 = allowed_squares1
        self.allowed_squares2 = allowed_squares2
        self.occupied_squares1 = occupied_squares1
        self.occupied_squares2 = occupied_squares2
        self.taboo = taboo

class SudokuAI(competitive_sudoku.sudokuai.SudokuAI):
    """
    Sudoku AI that computes a move for a given sudoku configuration.
    """

    def __init__(self):
        super().__init__()
        self.time_limit = 0.49
        self.points_by_regions = {0: 0, 1: 1, 2: 3, 3: 7}
        self.deadline = 0.0

    def compute_best_move(self, game_state: GameState) -> None:
        state = self._build_state(game_state)
        legal_moves = self._generate_legal_moves(state, state.current_player)
        if not legal_moves:
            return

        # Safe proposal
        fallback = self._best_local_move(state, legal_moves)
        self.propose_move(fallback)

        self.deadline = time.perf_counter() + self.time_limit
        depth = 1
        best_move = fallback
        perspective = state.current_player

        while time.perf_counter() < self.deadline:
            try:
                _, move = self._alpha_beta(state, depth, float("-inf"), float("inf"), perspective, False)
            except TimeoutError:
                break
            if move:
                best_move = move
                self.propose_move(best_move)
            depth += 1

    def _alpha_beta(
        self,
        state: SearchState,
        depth: int,
        alpha: float,
        beta: float,
        perspective: int,
        passed: bool,
    ) -> Tuple[float, Optional[Move]]:
        if time.perf_counter() >= self.deadline:
            raise TimeoutError

        legal_moves = self._generate_legal_moves(state, state.current_player)
        if depth == 0:
            return self._evaluate(state, perspective), None

        if not legal_moves:
            if passed:
                return self._evaluate(state, perspective), None
            return self._alpha_beta(self._switch_player(state), depth - 1, alpha, beta, perspective, True)

        maximizing = state.current_player == perspective
        best_move = None

        if maximizing:
            value = float("-inf")
            for move in self._order_moves(state, legal_moves):
                child = self._apply_move(state, move)
                score, _ = self._alpha_beta(child, depth - 1, alpha, beta, perspective, False)
                if score > value:
                    value, best_move = score, move
                alpha = max(alpha, value)
                if beta <= alpha:
                    break
            return value, best_move
        else:
            value = float("inf")
            for move in self._order_moves(state, legal_moves):
                child = self._apply_move(state, move)
                score, _ = self._alpha_beta(child, depth - 1, alpha, beta, perspective, False)
                if score < value:
                    value, best_move = score, move
                beta = min(beta, value)
                if beta <= alpha:
                    break
            return value, best_move
        
    # --- Move handling ----------------------------------------------------------

    def _apply_move(self, state: SearchState, move: Move) -> SearchState:
        board = SudokuBoard(state.board.m, state.board.n)
        board.squares = state.board.squares.copy()
        board.put(move.square, move.value)

        scores = state.scores.copy()
        completed = self._completed_regions(board, move.square)
        scores[state.current_player - 1] += self.points_by_regions[completed]

        occ1 = None if state.occupied_squares1 is None else list(state.occupied_squares1)
        occ2 = None if state.occupied_squares2 is None else list(state.occupied_squares2)
        if state.current_player == 1 and occ1 is not None:
            occ1.append(move.square)
        if state.current_player == 2 and occ2 is not None:
            occ2.append(move.square)

        return SearchState(
            board=board,
            scores=scores,
            current_player=3 - state.current_player,
            allowed_squares1=None if state.allowed_squares1 is None else list(state.allowed_squares1),
            allowed_squares2=None if state.allowed_squares2 is None else list(state.allowed_squares2),
            occupied_squares1=occ1,
            occupied_squares2=occ2,
            taboo=set(state.taboo),
        )   
    
    def _switch_player(self, state: SearchState) -> SearchState:
        return SearchState(
            board=state.board,
            scores=state.scores,
            current_player=3 - state.current_player,
            allowed_squares1=state.allowed_squares1,
            allowed_squares2=state.allowed_squares2,
            occupied_squares1=state.occupied_squares1,
            occupied_squares2=state.occupied_squares2,
            taboo=set(state.taboo),
        )
    
    # --- Move generation and evaluation --------------------------------------------

    def _generate_legal_moves(self, state: SearchState, player: int) -> List[Move]:
        allowed = self._allowed_squares_for_player(state, player)
        if allowed is None:
            candidates = [
                (i, j)
                for i in range(state.board.N)
                for j in range(state.board.N)
                if state.board.get((i, j)) == SudokuBoard.empty
            ]
        else:
            candidates = [sq for sq in allowed if state.board.get(sq) == SudokuBoard.empty]

        moves: List[Move] = []
        taboo = state.taboo
        N = state.board.N
        for square in candidates:
            r, c = square
            row_vals = {state.board.get((r, j)) for j in range(N) if state.board.get((r, j)) != SudokuBoard.empty}
            col_vals = {state.board.get((i, c)) for i in range(N) if state.board.get((i, c)) != SudokuBoard.empty}
            block_vals = self._block_values(state.board, square)
            disallowed = row_vals | col_vals | block_vals
            for value in range(1, N + 1):
                if value in disallowed:
                    continue
                if (r, c, value) in taboo:
                    continue
                moves.append(Move(square, value))
        return moves

    def _allowed_squares_for_player(self, state: SearchState, player: int) -> Optional[List[Square]]:
        allowed = state.allowed_squares1 if player == 1 else state.allowed_squares2
        occupied = state.occupied_squares1 if player == 1 else state.occupied_squares2
        N = state.board.N

        if allowed is None:
            return None

        def neighbors(square: Square):
            r, c = square
            for dr in (-1, 0, 1):
                for dc in (-1, 0, 1):
                    if dr == 0 and dc == 0:
                        continue
                    nr, nc = r + dr, c + dc
                    if 0 <= nr < N and 0 <= nc < N:
                        yield nr, nc

        result = [sq for sq in allowed if state.board.get(sq) == SudokuBoard.empty]
        if occupied is not None:
            for sq in occupied:
                for neigh in neighbors(sq):
                    if state.board.get(neigh) == SudokuBoard.empty:
                        result.append(neigh)
        return sorted(set(result))

    def _evaluate(self, state: SearchState, perspective: int) -> float:
        score_diff = state.scores[perspective - 1] - state.scores[2 - perspective]
        my_moves = self._generate_legal_moves(state, perspective)
        opp_moves = self._generate_legal_moves(state, 3 - perspective)
        best_my_gain = self._best_gain(state.board, my_moves)
        best_opp_gain = self._best_gain(state.board, opp_moves)
        mobility_diff = len(my_moves) - len(opp_moves)
        return 10 * score_diff + 3 * (best_my_gain - best_opp_gain) + 0.5 * mobility_diff

    def _best_gain(self, board: SudokuBoard, moves: List[Move]) -> int:
        if not moves:
            return 0
        return max(self.points_by_regions[self._completed_regions_after_move(board, m)] for m in moves)

    def _best_local_move(self, state: SearchState, moves: List[Move]) -> Move:
        ordered = self._order_moves(state, moves)
        return ordered[0]

    def _order_moves(self, state: SearchState, moves: List[Move]) -> List[Move]:
        return sorted(
            moves,
            key=lambda m: (
                -self.points_by_regions[self._completed_regions_after_move(state.board, m)],
                self._centrality(state.board, m.square),
            ),
        )

    def _block_values(self, board: SudokuBoard, square: Square) -> set:
        m, n = board.m, board.n
        top = (square[0] // m) * m
        left = (square[1] // n) * n
        values = set()
        for i in range(top, top + m):
            for j in range(left, left + n):
                val = board.get((i, j))
                if val != SudokuBoard.empty:
                    values.add(val)
        return values

    def _completed_regions(self, board: SudokuBoard, square: Square) -> int:
        N = board.N
        r, c = square
        row_complete = all(board.get((r, j)) != SudokuBoard.empty for j in range(N))
        col_complete = all(board.get((i, c)) != SudokuBoard.empty for i in range(N))
        block_complete = all(
            board.get((i, j)) != SudokuBoard.empty
            for i in range((r // board.m) * board.m, (r // board.m) * board.m + board.m)
            for j in range((c // board.n) * board.n, (c // board.n) * board.n + board.n)
        )
        return int(row_complete) + int(col_complete) + int(block_complete)

    def _completed_regions_after_move(self, board: SudokuBoard, move: Move) -> int:
        tmp = SudokuBoard(board.m, board.n)
        tmp.squares = board.squares.copy()
        tmp.put(move.square, move.value)
        return self._completed_regions(tmp, move.square)

    def _centrality(self, board: SudokuBoard, square: Square) -> float:
        center = (board.N - 1) / 2
        return abs(square[0] - center) + abs(square[1] - center)

    def _build_state(self, game_state: GameState) -> SearchState:
        board = SudokuBoard(game_state.board.m, game_state.board.n)
        board.squares = game_state.board.squares.copy()
        taboo = {(m.square[0], m.square[1], m.value) for m in game_state.taboo_moves}
        return SearchState(
            board=board,
            scores=list(game_state.scores),
            current_player=game_state.current_player,
            allowed_squares1=None if game_state.allowed_squares1 is None else list(game_state.allowed_squares1),
            allowed_squares2=None if game_state.allowed_squares2 is None else list(game_state.allowed_squares2),
            occupied_squares1=None if game_state.occupied_squares1 is None else list(game_state.occupied_squares1),
            occupied_squares2=None if game_state.occupied_squares2 is None else list(game_state.occupied_squares2),
            taboo=taboo,
        )
